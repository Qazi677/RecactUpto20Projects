import React from "react";
import Container from "../Container/Container";

export default function About() {
  return (
    <Container>
      <h2>About ShopEase</h2>
      <p>
        ShopEase is your one-stop online store where quality meets convenience.
        Browse our curated collection and enjoy seamless shopping!
      </p>
    </Container>
  );
}
