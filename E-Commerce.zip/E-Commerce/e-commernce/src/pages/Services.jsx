import React from "react";
import Container from "../Container/Container";

export default function Services() {
  return (
    <Container>
      <h2>Our Services</h2>
      <p>
        We provide free shipping, easy returns, and 24/7 customer support for
        all your shopping needs.
      </p>
    </Container>
  );
}
