import React, { useContext } from "react";
import { Link } from "react-router-dom";
import "./Header.css";
import { CartContext } from "../cartContex/cartContext";

export default function Header() {
  const { cart } = useContext(CartContext);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="flex Header-container">
      <div>
        <Link to="/" className="logo">ShopEase</Link>
      </div>

      <div className="flex">
        <ul className="flex list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>

        <Link to="/cart" className="cart-icon">
          🛒
          {totalItems > 0 && <span className="cart-count">{totalItems}</span>}
        </Link>
      </div>
    </div>
  );
}
