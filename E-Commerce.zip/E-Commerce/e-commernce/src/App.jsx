import { Routes, Route } from "react-router-dom";
import { CartProvider } from "./cartContex/cartContext";
import Header from "./Header/Header";
import Home from "./home/Home";
import Cart from "./Cart/Cart";
import "./App.css";

function App() {
  return (
    <CartProvider>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </CartProvider>
  );
}

export default App;
