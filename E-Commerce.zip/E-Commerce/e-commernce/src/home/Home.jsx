import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import "./Home.css";
import Container from "../Container/Container";
import { CartContext } from "../cartContex/cartContext";

function Home() {
  const { addToCart } = useContext(CartContext);
  const [product, setProduct] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://hplussport.com/api/products/order/price"
        );
        setProduct(response.data);
      } catch (error) {
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <Container>Loading...</Container>;
  if (error)
    return <Container>Something went wrong while fetching data.</Container>;

  return (
    <Container>
      <h1>Products</h1>
      <ul className="u-list">
        {product.map((item) => (
          <li key={item.id}>
            <img className="product-img" src={item.image} alt={item.name} />
            <h2>{item.name}</h2>
            <div className="down">
              <h4>${item.price}</h4>
              <button onClick={() => addToCart(item)}>Add To Cart</button>
            </div>
          </li>
        ))}
      </ul>
    </Container>
  );
}

export default Home;
