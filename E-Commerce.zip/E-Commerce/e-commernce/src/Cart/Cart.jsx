import React, { useContext } from "react";
import { CartContext } from "../cartContex/cartContext";
import Container from "../Container/Container";

export default function Cart() {
  const { cart, removeFromCart, increaseQty, decreaseQty } =
    useContext(CartContext);

  if (cart.length === 0) {
    return (
      <Container>
        <p>Your cart is empty 🛍️</p>
      </Container>
    );
  }

  const totalAmount = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  return (
    <Container>
      <h2>Your Cart</h2>
      {cart.map((item) => (
        <div
          key={item.id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #ccc",
            padding: "10px 0",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <img
              src={item.image}
              alt={item.name}
              width="60"
              height="60"
              style={{ borderRadius: "8px" }}
            />
            <div>
              <h4>{item.name}</h4>
              <p>${item.price.toFixed(2)}</p>
            </div>
          </div>

          <div>
            <button onClick={() => decreaseQty(item.id)}>-</button>
            <span style={{ margin: "0 10px" }}>{item.quantity}</span>
            <button onClick={() => increaseQty(item.id)}>+</button>
          </div>

          <p style={{ width: "100px", textAlign: "right" }}>
            ${(item.price * item.quantity).toFixed(2)}
          </p>

          <button
            onClick={() => removeFromCart(item.id)}
            style={{
              background: "red",
              color: "white",
              border: "none",
              padding: "5px 10px",
              borderRadius: "5px",
            }}
          >
            Remove
          </button>
        </div>
      ))}

      <h3 style={{ textAlign: "right", marginTop: "20px" }}>
        Grand Total: ${totalAmount.toFixed(2)}
      </h3>
    </Container>
  );
}
