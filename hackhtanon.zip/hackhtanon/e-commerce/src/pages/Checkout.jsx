import React from 'react'

export default function Checkout() {
  return (
    <div>Checkout</div>
  )
}
